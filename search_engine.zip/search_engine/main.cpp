#include <fstream>
#include <exception>
#include <unordered_set>
#include <unordered_map>
#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <thread>
#include <mutex>
#include "nlohmann/json.hpp"

const std::string VERSION = "0.1.0";

class JSON_NonFound_exception: public std::exception {
public:
    const char* what() const noexcept override {
        return "Error! Config file missing.";
    }
};

class Files_in_config_exception: public std::exception {
public:
    const char* what() const noexcept override {
        return "Error! Files not found in config.";
    }
};

class Version_exception: public std::exception {
public:
    const char* what() const noexcept override {
        return "Error! config.json has incorrect file version.";
    }
};

class Config_empty_exception: public std::exception {
public:
    const char* what() const noexcept override {
        return "Error! Config file is empty.";
    }
};

class Name_empty_exception:public std::exception {
public:
    const char* what() const noexcept override {
        return "Error! Name of engine is empty.";
    }
};

class Requests_NonFound_exception: public std::exception {
public:
    const char* what() const noexcept override {
        return "Error! Requests file missing.";
    }
};

class Contains_requests_exception: public std::exception {
public:
    const char* what() const noexcept override {
        return "Error! Requests are empty.";
    }
};

class Requests_size_exception: public std::exception {
public:
    const char* what() const noexcept override {
        return "Error! Too many requests.";
    }
};

class Answers_NonFound_exception: public std::exception {
public:
    const char* what() const noexcept override {
        return "Error! Answers file missing.";
    }
};

class ConverterJSON {
private:
    std::string config_json_path = "config.json";
    std::string requests_json_path = "requests.json";
    std::string answers_json_path = "answers.json";
    std::string name;

public:
    ConverterJSON () = default;

    std::string get_name () const {
        return name;
    }

    bool check_version (nlohmann::json& js) {
        if (js.contains("config") && js["config"].contains("version")) {
            std::string ver_in_file = js["config"]["version"].get<std::string>();
            return ver_in_file == VERSION;
        } else return false;
    }

    std::vector<std::string> GetTextDocuments() {
        std::vector<std::string> list_file;

        try {
            std::ifstream file_config (config_json_path);
            if (!file_config.is_open()) {
                throw JSON_NonFound_exception();
            }

            nlohmann::json config_json;
            file_config >> config_json;

            if (config_json.find("config") == config_json.end()) {
                throw Config_empty_exception();
            }

            if (config_json.find("files") == config_json.end()) {
                throw Files_in_config_exception();
            }

            if (!check_version(config_json)) {
                throw Version_exception();
            }

            if (config_json["config"].find("name") == config_json["config"].end()) {
                throw Name_empty_exception ();
            }

            name = config_json["config"]["name"].get<std::string>();

            for (const auto& file_name : config_json["files"]) {
                if (!file_name.is_string()) continue;

                std::string file_name_str = file_name.get<std::string>();
                list_file.push_back(file_name_str);
            }

            file_config.close();

        } catch (const Files_in_config_exception& ex) {
            std::cerr << ex.what() << std::endl;
        } catch (const JSON_NonFound_exception& ex) {
            std::cerr << ex.what() << std::endl;
        } catch (const Version_exception& ex) {
            std::cerr << ex.what() << std::endl;
        } catch (const Config_empty_exception& ex) {
            std::cerr << ex.what() << std::endl;
        } catch (const Name_empty_exception& ex) {
            std::cerr << ex.what() << std::endl;
        }

        return list_file;
    }

    int GetResponsesLimit(nlohmann::json& js) {
        if (js["config"].find("max_responses") == js["config"].end()) {
            return 5;
        } else {
            int response = js["config"]["max_responses"].get<int>();
            return response;
        }
    }

    bool correct_word (const std::string& str) {
        std::vector<std::string> words;
        std::string current_word;

        for (const char c : str) {
            if (c >= 'a' && c <= 'z') {
                current_word += c;
            } else if (c == ' ') {
                if (!current_word.empty()) {
                    words.push_back(current_word);
                    current_word.clear();
                }
            } else return false;
        }

        if (!current_word.empty()) words.push_back(current_word);

        if (words.empty() || words.size() > 10) return false;

        return true;
    }

    std::vector<std::string> GetRequests () {
        std::vector<std::string> buffer;

        try {
            std::ifstream file_requests (requests_json_path);
            if (!file_requests.is_open()) {
                throw Requests_NonFound_exception();
            }

            nlohmann::json requests_json_file;
            file_requests >> requests_json_file;

            if (requests_json_file.find("requests") == requests_json_file.end()) {
                throw Contains_requests_exception();
            }

            if (requests_json_file["requests"].size() > 1000) {
                throw Requests_size_exception();
            }

            for (const auto& req : requests_json_file["requests"]) {
                if (!req.is_string()) continue;
                std::string req_str = req.get<std::string>();
                if (!correct_word(req_str)) continue;
                buffer.push_back(req_str);
            }

            file_requests.close();

        } catch (const Requests_NonFound_exception& ex) {
            std::cerr << ex.what() << std::endl;
        } catch (const Contains_requests_exception& ex) {
            std::cerr << ex.what() << std::endl;
        } catch (const Requests_size_exception& ex) {
            std::cerr << ex.what() << std::endl;
        }

        return buffer;
    }

    void putAnswers(std::vector<std::vector<std::pair<int,float>>> answers) {
        try {
            std::vector<std::string> req_vec = GetRequests();
            if (req_vec.empty()) {
                throw Contains_requests_exception();
            }

            std::ofstream file_answers (answers_json_path, std::ios::trunc);
            if (!file_answers.is_open()) {
                throw Answers_NonFound_exception();
            }

            nlohmann::json answers_json_file = nlohmann::json::object();

            size_t req_count = req_vec.size();
            for (int i = 0; i < req_count; i++) {
                std::string req_id = "request" + std::to_string(i + 1);

                nlohmann::json req_ret;
                if (i >= answers.size()) {
                    req_ret["result"] = "false";
                } else {
                    const auto& ans = answers[i];
                    if (ans.empty()) {
                        req_ret["result"] = "false";
                    } else {
                        req_ret["result"] = "true";

                        nlohmann::json relevance = nlohmann::json::array();
                        for (const auto& pair : ans) {
                            int docid = pair.first;
                            float rank = pair.second;
                            if (docid >= 0) {
                                nlohmann::json obj;
                                obj["docid"] = docid;
                                obj["rank"] = rank;
                                relevance.push_back(obj);
                            }
                        }
                        req_ret["relevance"] = relevance;
                    }
                }

                answers_json_file["answers"][req_id] = req_ret;
            }

            file_answers << answers_json_file;
            file_answers.close();
            
        } catch (const Contains_requests_exception& ex) {
            std::cerr << ex.what() << std::endl;
        } catch (const Answers_NonFound_exception& ex) {
            std::cerr << ex.what() << std::endl;
        }
    }
};

struct Entry {
    size_t doc_id, count;

    bool operator== (const Entry& other) const {
        return (doc_id == other.doc_id && count == other.count);
    }
};

class InvertedIndex {
private:
    std::vector<std::string> docs;
    std::map<std::string, std::vector<Entry>> freq_dictionary;
    std::vector<std::thread> threads;
    std::mutex mtx;

    std::vector<std::string> split_to_words (const std::string& str) {
        std::vector<std::string> words;
        std::string current_word;
        for (char c : str) {
            if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) {
                current_word += static_cast<char>(std::tolower(c));
            } else {
                if (!current_word.empty()) {
                    words.push_back(current_word);
                    current_word.clear();
                }
            }
        }

        if (!current_word.empty()) {
            words.push_back(current_word);
        }

        return words;
    }

public:
    InvertedIndex() = default;
    
    void UpdateDocumentBase (std::vector<std::string> input_docs) {
        docs = input_docs;
        freq_dictionary.clear();

        for (size_t i = 0; i < docs.size(); i++) {
            threads.emplace_back([&, i] () {
                std::vector<std::string> words = split_to_words(docs[i]);
        
                std::map<std::string, size_t> oMap;
                mtx.lock();
                for (const auto& word : words) {
                    oMap[word]++;
                }
                mtx.unlock();

                mtx.lock();
                for (const auto& pair : oMap) {
                    Entry entry {i, pair.second};
                    freq_dictionary[pair.first].push_back(entry);
                }
                mtx.unlock();
            });
        }

        for (auto& t : threads) {
            if (t.joinable()) t.join();
        }

        threads.clear();
    }
    
    std::vector<Entry> GetWordCount (const std::string& word) {
        auto it = freq_dictionary.find(word);
        if (it != freq_dictionary.end()) {
            return it->second;
        } else {
            return {};
        }
    }

    auto get_freq () {
        return freq_dictionary;
    }
};

struct RelativeIndex {
    size_t doc_id;
    float rank;

    bool operator== (const RelativeIndex& other) const {
        return(doc_id == other.doc_id && rank == other.rank);
    }
};

class SearchServer {
private:
    InvertedIndex& _index;
    std::map<std::string, size_t> word_freqs_map;

    bool compare_freq (const std::pair<std::string, size_t>& a, const std::pair<std::string, size_t>& b) {
        return a.second < b.second;
    }

    std::vector<std::string> split_and_unique (const std::string& str) {
        std::vector<std::string> words;
        std::string current_word;
        for (char c : str) {
            if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) {
                current_word += static_cast<char>(std::tolower(c));
            } else {
                if (!current_word.empty()) {
                    words.push_back(current_word);
                    current_word.clear();
                }
            }
        }

        if (!current_word.empty()) {
            words.push_back(current_word);
        }
        
        std::unordered_set<std::string> unique_words (words.begin(), words.end());
        words.assign(unique_words.begin(), unique_words.end());

        return words;
    }

public:
    SearchServer(InvertedIndex& idx): _index(idx) {
        auto index_freq = _index.get_freq();
        for (const auto& pair : index_freq) {
            const std::string& word = pair.first;
            const auto& entries = pair.second;
            size_t total = 0;
            for (const auto& entry : entries) {
                total += entry.count;
            }
            word_freqs_map[word] = total;
        }
    }

    std::vector<std::vector<RelativeIndex>> search (const std::vector<std::string>& queries_input) {
        std::vector<std::vector<RelativeIndex>> result;

        for (const auto& query : queries_input) {
            std::vector<std::string> unique = split_and_unique(query);

            std::vector<std::pair<std::string, size_t>> words_freq;
            
            for (const auto& w : unique) {
                auto it = word_freqs_map.find(w);
                size_t freq;
                if (it != word_freqs_map.end()) {
                    freq = it->second;
                } else {
                    freq = SIZE_MAX;
                }

                words_freq.emplace_back(w, freq);
            }

            std::sort(words_freq.begin(), words_freq.end(), [this](const auto& a, const auto& b) {
                return compare_freq(a, b);
            });

            const auto& first_word = words_freq.front().first;
            auto docs_for_first = _index.GetWordCount(first_word);
            if (docs_for_first.empty()) {
                result.push_back({});
                continue;
            }

            std::unordered_set<size_t> doc_ids;
            for (const auto& entry : docs_for_first) {
                doc_ids.insert(entry.doc_id);
            }

            std::unordered_map<size_t, float> relMap;
            for (const auto& entry : docs_for_first) {
                relMap[entry.doc_id] += static_cast<float>(entry.count);
            }

            for (size_t i = 1; i < words_freq.size(); i++) {
                const auto& word = words_freq[i].first;
                auto cur = _index.GetWordCount(word);
                if (cur.empty()) {
                    doc_ids.clear();
                    break;
                }

                std::unordered_set<size_t> new_doc_ids;
                std::unordered_map<size_t, float> new_relMap;

                std::unordered_map<size_t, float> temp_map;
                for (const auto& entry : cur) {
                    temp_map[entry.doc_id] = static_cast<float>(entry.count);
                }

                for (size_t id : doc_ids) {
                    if (temp_map.count(id)) {
                        new_doc_ids.insert(id);
                        new_relMap[id] = relMap[id] + temp_map[id];
                    }
                }

                doc_ids = new_doc_ids;
                relMap = new_relMap;

                if (doc_ids.empty()) break;
            }

            std::vector<RelativeIndex> rel_result;
            float rel_max = .0f;
            for (const auto& pair : relMap) {
                if (pair.second > rel_max) {
                    rel_max = pair.second;
                }
            }

            if (rel_max == .0f) {
                rel_max = 1.0f;
            }

            for (size_t id : doc_ids) {
                float rel = relMap[id] / rel_max;
                rel_result.push_back(RelativeIndex{id, rel});
            }

            std::sort (rel_result.begin(), rel_result.end(), [] (const RelativeIndex& a, const RelativeIndex& b) {
                    return a.rank > b.rank;
                }
            );

            result.push_back(rel_result);
        }

        return result;
    }     
};

std::vector<std::vector<std::pair<int, float>>> convert (const std::vector<std::vector<RelativeIndex>>& input) {
    std::vector<std::vector<std::pair<int, float>>> result;
    result.reserve(input.size());

    for (const auto& rel_vec : input) {
        std::vector<std::pair<int, float>> change_vec;
        change_vec.reserve(rel_vec.size());

        for (const auto& rel_Idx : rel_vec) {
            change_vec.emplace_back(static_cast<int>(rel_Idx.doc_id), rel_Idx.rank);
        }
        result.emplace_back(std::move(change_vec));
    }

    return result;
}

int main () {
    ConverterJSON converter;

    auto files = converter.GetTextDocuments();
    std::string name = converter.get_name();
    if (!name.empty()) {
        std::cout << name << " has start!" << std::endl;
    }

    InvertedIndex index;
    index.UpdateDocumentBase(files);

    auto requests = converter.GetRequests();

    SearchServer server(index);

    auto result = server.search(requests);
    auto answers = convert(result);
    converter.putAnswers(answers);

    system("pause"); // чтобы окно терминала сразу не закрывалось
}